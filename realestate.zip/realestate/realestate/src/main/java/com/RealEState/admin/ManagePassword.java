package com.RealEState.admin;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Random;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.RealEState.database.DbConnection;
import com.RealEState.login.User;
import com.RealEState.model.Email;


/**
 * Servlet implementation class ManagePassword
 */
@WebServlet("/ManagePassword")
public class ManagePassword extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Connection con;
	DbConnection dbConnecion;

	public ManagePassword() {
		super();
		try {
			con = dbConnecion.getConnection();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		String action = request.getParameter("action");
		switch (action) {

		case "sendOtp":

			sendOtp(request, response);
			break;
			
		case "setNewPassword":
			
			setNewPassword(request, response);
			break;

		default:

			break;

		}
	}

	private void setNewPassword(HttpServletRequest request, HttpServletResponse response) throws IOException {
		
		
		String email = request.getParameter("email");
		
		String newPassword = request.getParameter("newPassword");
		
		int otp = Integer.parseInt(request.getParameter("otp")); 
		
		User u = new User();
		u.setEmail(email);
		u.setOtp(otp);
		u.setPassword(newPassword);
		try {
			if(u.checkOtp(con)>=1) {
				
				u.updatePassWord(con);
				
				response.getWriter().write("Success, password updated ");
				
			}else {
				
				response.getWriter().write("fail,Invalid otp");
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
			response.getWriter().write("fail,Internal error contact admin");
		}
		
		
		
		
		
	}

	private void sendOtp(HttpServletRequest request, HttpServletResponse response) throws IOException {

		/* int otp = Integer.parseInt(request.getParameter("otp")); */
		String email = request.getParameter("email");

		System.out.println("=========" + email);
		int flag = 0;

		User u = new User();
		u.setEmail(email);

		try {
			if (u.isUserAvaible(con)) {

				Random r = new Random();
				int low = 10;
				int high = 20000;
				int result = r.nextInt(high - low) + low;

				u.setOtp(result);

				if (u.updateOtp(con) == 1) {
					Email em = new Email();
					flag = em.SentMail(email,u.getOtp());

					if (flag == 0) {

						response.getWriter().write("Otp sent to your email id  ");
					} else {

						response.getWriter().write("Inetrnal error contact admin ");

					}

				}

				} else {

				response.getWriter().write("User not found with given email");
			}

		} catch (SQLException | IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();

			response.getWriter().write("Inetrnal error ");
		}

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
