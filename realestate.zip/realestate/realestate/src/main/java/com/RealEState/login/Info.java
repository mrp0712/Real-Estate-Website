package com.RealEState.login;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class Info {
	private int id;
	
	private String name;
	private String email;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	private String msg;
	
	public int insert(Connection con) throws SQLException{
		
		String sql= "INSERT INTO `realestate`.`info`(`name`,`email`,`msg`)";
		sql += "VALUES(?,?,?)";
		
		PreparedStatement ps = con.prepareStatement(sql);
		int i=0;
		ps.setString(++i, name);
		ps.setString(++i, email);
		ps.setString(++i, msg);
		
	
		return ps.executeUpdate();
		
	}
	public List<Info> getInfoList(Connection con) throws SQLException {
		String sql = "Select  * from `realestate`.`info`";
		List<Info> infoList = new ArrayList<>();

		int count = 0;
		PreparedStatement ps = con.prepareStatement(sql);
		int i = 0;

		System.out.println("SQL  select******===>" + ps.toString());

		ResultSet rs = ps.executeQuery();
		//User u;
		Info ui;
		while (rs.next()) {
			ui = new Info();

			ui.setId(rs.getInt("id"));

			ui.setEmail(rs.getString("email"));
			ui.setName(rs.getString("name"));
			ui.setMsg(rs.getString("msg"));
			
			infoList.add(ui);

		}

		return infoList;
	}
	public void deleteInfo(Connection con) throws SQLException{
		// TODO Auto-generated method stub
		
		String sql = "delete from `realestate`.`info` where id=?";
		PreparedStatement ps= con.prepareStatement(sql);
		ps.setInt(1, id);
		
		ps.execute();
		ps.close();
		
	}
	

}
