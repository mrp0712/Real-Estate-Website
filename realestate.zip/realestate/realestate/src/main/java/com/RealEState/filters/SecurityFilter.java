package com.RealEState.filters;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.RealEState.login.User;

public class SecurityFilter implements Filter {

	@Override
	public void doFilter(ServletRequest req, ServletResponse res, FilterChain arg2)
			throws IOException, ServletException {
		// TODO Auto-generated method stub
		System.out.println("filter called===============>");
		// HttpSession session =req.get

		HttpServletRequest request = (HttpServletRequest) req;

		HttpServletResponse response = (HttpServletResponse) res;
		HttpSession session = (HttpSession) request.getSession();
		User currentuser = (User) session.getAttribute("user");

		System.out.println("url==>	" + request.getRequestURI());

		/*
		 * if (currentuser == null &&
		 * !request.getRequestURI().equals("/CafeZone/index.jsp")) {
		 * 
		 * response.sendRedirect(request.getContextPath() + "/index.jsp");
		 * 
		 * }
		 */
		arg2.doFilter(req, res);
	}

}
