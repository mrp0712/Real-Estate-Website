package com.RealEState.admin;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

import org.apache.tomcat.util.http.fileupload.FileItem;
import org.apache.tomcat.util.http.fileupload.FileUtils;
import org.apache.tomcat.util.http.fileupload.disk.DiskFileItemFactory;
import org.apache.tomcat.util.http.fileupload.servlet.ServletFileUpload;

import com.RealEState.database.DbConnection;
import com.RealEState.login.User;
import com.RealEState.model.Product;

/**
 * Servlet implementation class ManageProducts
 */
@WebServlet("/ManageProducts")
@MultipartConfig
public class ManageProducts extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	Connection con;
	DbConnection dbConnecion;
	User currentuser;

	public ManageProducts() {
		super();
		try {
			con = dbConnecion.getConnection();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		HttpSession session = request.getSession();
		currentuser = (User) session.getAttribute("user");

		System.out.println("user====>" + currentuser.getFirstName());
		String action = request.getParameter("action");

		int i = 0;

		switch (action) {
		case "productList":
			showProductList(request, response);
			break;

		case "insertOrUpdate":

			insertUpdateProduct(request, response);
			break;

		case "deleteproduct":

			deleteProduct(request, response);
			break;
		case "productform":
			getProduct(request, response);
			break;
		case "addProduct":
			addProduct(request, response);
			break;
		case "showproductlistforuser":
			showProductListForUser(request, response);
			break;
			
		
		default:

			break;

		}

	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();
		currentuser = (User) session.getAttribute("user");

		System.out.println("user====****************>" + currentuser.getFirstName());

		String action = request.getParameter("action");

		int i = 0;

		switch (action) {
		case "productList":
			showProductList(request, response);
			break;

		case "insertOrUpdate":

			insertUpdateProduct(request, response);
			break;

		case "deleteproduct":
			deleteProduct(request, response);
			break;

		case "productform":
			getProduct(request, response);
			break;

		case "addProduct":
			addProduct(request, response);
			break;

		case "showproductlistforuser":
			showProductListForUser(request, response);
			break;
		
		default:

			break;

		}

	}

	private void addProduct(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.getRequestDispatcher("/product.jsp").forward(request, response);

	}

	private void insertUpdateProduct(HttpServletRequest request, HttpServletResponse response) {

		String productName = request.getParameter("productName");
		String productdescription = request.getParameter("prodDesc");
		String productPrice = request.getParameter("price");
		String productType = request.getParameter("product-type");

		Product product = new Product();

		product.setProduct_name(productName);
		product.setProduct_details(productdescription);
		product.setProduct_type(productType);
		product.setPrice(Integer.parseInt(productPrice));

		System.out.println("productType===>" + productType);
		/* String productImage = request.getParameter("productImage"); */

		try {
			Part imagePart = request.getPart("productImage");
			InputStream fileContent = imagePart.getInputStream();
			String imagesPath = request.getRealPath("\\webapp\\products");

			System.out.println("imagesPath==>" + imagesPath);
			String checkContentType[] = imagePart.getContentType().split("/");
			String id = request.getParameter("productId");

			if (checkContentType[1].equalsIgnoreCase("png") || checkContentType[1].equalsIgnoreCase("jpeg")
					|| checkContentType[1].equalsIgnoreCase("jpg")) {

				File f = new File(imagesPath, imagePart.getSubmittedFileName());

				org.apache.commons.io.FileUtils.copyInputStreamToFile(fileContent, f);

				System.out.println("loaction===>" + f.getPath());

				System.out.println("contentType" + imagePart.getContentType());

				product.setProduct_image(imagePart.getSubmittedFileName());
				product.setProduct_image_alterd_name(imagePart.getSubmittedFileName());

				if (id != null && !id.isEmpty()) {

					int prodId = Integer.parseInt(id);

					product.setId(prodId);
					product.update(con);

				} else {

					product.insert(con);
				}

				response.sendRedirect(request.getContextPath() + "/ManageProducts?action=productList");

			} else {

				System.out.println("invalid file");

				request.getRequestDispatcher("/product.jsp").forward(request, response);

			}

		} catch (IOException | ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void showProductList(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		Product product = new Product();

		try {
			List<Product> productList = product.getProducts(con);

			for (Iterator iterator = productList.iterator(); iterator.hasNext();) {
				Product products = (Product) iterator.next();
				System.out.println(products.getProduct_name());

			}
			System.out.println("productList==>" + productList.size());

			request.setAttribute("productsList", productList);

			RequestDispatcher rd = request.getRequestDispatcher("/productList.jsp");

			rd.forward(request, response);

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception ex) {
			// TODO Auto-generated catch block
			ex.printStackTrace();
		}
	}

	public void getProduct(HttpServletRequest request, HttpServletResponse response) {

		int productId = Integer.parseInt(request.getParameter("productId"));

		try {
			Product p = new Product();
			p.setId(productId);
			request.setAttribute("product", p.getProduct(con));
			request.getRequestDispatcher("/product.jsp").forward(request, response);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

	}

	private void deleteProduct(HttpServletRequest request, HttpServletResponse response) {
		int productId = Integer.parseInt(request.getParameter("productId"));

		try {
			Product p = new Product();
			p.setId(productId);
			p.deleteProduct(con);
			response.sendRedirect(request.getContextPath() + "/ManageProducts?action=productList");
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}

	public void showProductListForUser(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		Product product = new Product();

		try {
			List<Product> productList = product.getProducts(con);
			List<Product> productSpecailList = product.getSpecailProducts(con);
		
			System.out.println("productList==>" + productList.size());

			request.setAttribute("productsList", productSpecailList);
			request.setAttribute("specialProductsList",   productList);
			RequestDispatcher rd = request.getRequestDispatcher("/productcatalog.jsp");

			rd.forward(request, response);

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception ex) {
			// TODO Auto-generated catch block
			ex.printStackTrace();
		}
	}

}
