package com.RealEState.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DbConnection {

	
		private final static String connectionStr ="jdbc:mysql://localhost:3307/realestate";
		private final static String userName="root";
		private final static String password="test";
		static Connection con;
		
		
		private final static String driverClass="com.mysql.cj.jdbc.Driver";
		
		
		
		
		public static  Connection getConnection() throws SQLException, ClassNotFoundException {
			
			Class.forName(driverClass);  
			con=DriverManager.getConnection(connectionStr,userName,password);
			
			return con;
			
		}

	}


